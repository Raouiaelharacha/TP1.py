'''
def decimal_to_binairy(n):
    binary=""
    while(n!=0):
        binary+=str(n % 2)
        n = n // 2
    return binary[::-1]
n=int(input("donner la valeur de n"))
print("la conversion est :",decimal_to_binairy(n) )
def somme(n):
    if n<=0:
        return 0 
    else:
            return ( n + somme(n-1) )
    
        
    
n=int(input("donner la valeur de n"))
print("la soome est:",somme(n))
def fibonacci(n):
    if(n <= 1):
        return n
    else:
        return (fibonacci(n-1) + fibonacci(n-2))
n = int(input("Entrez le nombre de termes:"))
print("Suite de Fibonacci en utilisant la recursion :")
for i in range(n):
    print(fibonacci(i))
    



# factorial function 
def factorial(a):
    # End of recursion criteria (this will stop the recursion)
    if a == 1: return a
    # Determinate the factorial by recursion
    return a * factorial(a - 1)

# Main function <== 
def determinate(c):
    # Declaration of the accumaltor variable (final result) 
    result = 0
    # Declaration of the main loop that reduce to last 
    for i in range(1, c + 1):
        result = (factorial(i)/i) + result
    # Final result 
    return result

# affichage de la resultat final
print(determinate(int(input("hello put my things here \n"))))





def somme(n):
  return sum(int(i)for i in str(n))
       
n=int(input("donner la valeur de n"))
print("la somme est:",somme(n))

# Programme Python pour l'implémentation du tri par insertion
def tri_insertion(tab): 
    # Parcour de 1 à la taille du tab
    for i in range(1, len(tab)): 
        k = tab[i] 
        j = i-1
        while j >= 0 and k < tab[j] : 
                tab[j + 1] = tab[j] 
                j -= 1
        tab[j + 1] = k


# Programme principale pour tester le code ci-dessus
tab = [98, 22, 15, 32, 2, 74, 63, 70]
tri_insertion(tab) 
print ("Le tableau trié est:")
for i in range(len(tab)): 
    print ("% d" % tab[i])
def tri_selection(tab):

   for i in range(len(tab)):

      # Trouver le min
       min = i

       for j in range(i+1, len(tab)):
           if tab[min] > tab[j]:
               min = j
                
       tmp = tab[i]
       tab[i] = tab[min]
       tab[min] = tmp

   return tab

# Programme principale pour tester le code ci-dessus
tab = [98, 22, 15, 32, 2, 74, 63, 70]
 
tri_selection(tab)
 
print ("Le tableau trié est:")
for i in range(len(tab)):
    print ("%d" %tab[i])
     # Programme Python pour l'implémentation du Tri à bulle
 
def tri_bulle(tab):
    n = len(tab)
    # Traverser tous les éléments du tableau
    for i in range(n):
        for j in range(0, n-i-1):
            # échanger si l'élément trouvé est plus grand que le suivant
            if tab[j] > tab[j+1] :
                tab[j], tab[j+1] = tab[j+1], tab[j]


# Programme principale pour tester le code ci-dessus
tab = [98, 22, 15, 32, 2, 74, 63, 70]
 
tri_bulle(tab)
 
print ("Le tableau trié est:")
for i in range(len(tab)):
    print ("%d" %tab[i])
def inverser_cahine(str):
    str1=[]
    i=len(str)
    while i>0:
        str1+=str[i-1]
        i-=1
    return str1

str=input("donner une chaine caractere")
print("chaine inverser est:",inverser_cahine(str))
def freq_carac(str,x):
    n=0
    if x in str:
        n+=1
    return n
str = input("donner str")
x=input("donner le caractere a trouver")
print("la freq du x est %d :",freq_carac(str))
def distinguer(list):
    l1=[]
    l2=[]
   
    for i in list:
        b=list.index(i)
        if b%2==0:
             l1.append(i)

        else:
            l2.append(i)
    
    return l2,l1

list=[1,2,4,8,3,6,2,56.20,22,12]
print("les listes sont:",distinguer(list))


def div_list(l):
    l1=[]
    for i in range(0,len(l),3):
        l1.append(l[i : i+3])
    return l1
l=[1,2,3,4,5,6,7,8,9]
print("les listes sont",div_list(l))'''


def difference(set1, set2):
    a = set((""))
    for i in set1:
        for j in set2: 
            if i == j: a.add(i)
    b = set1.copy()
    for i in set1:
        if i in a: b.remove(i)#supp les valeurs comuns avec set2et qui se trouve dans a

    print("this is the difference => ", a, "this is the remainder of set1", b)

# print(difference({23, 42, 65, 57, 78, 83, 29}, {57, 83, 29, 67, 73, 43)
def fnct(liste,dict):
    res=[]
    keys=list(dict.keys())#pour rendre les keys de la dict sous forme d'une liste
    for i in keys :
        for x in liste:
            if dict[str(i)]==x:
                res.append(x)      
    return res
l=[1,2,3,4,5,7]
dict={'raouia':1 ,'kk':2 ,'oo':3}
print(fnct(l,dict))     

def occurence(list1):
    a = {}
    for i in list1:
       if str(i) in a:
         a[str(i)] = 1 a.get(str(i))+1
       else:
            a[str(i)] = 1
    return a

print(occurence([1, 3, 4, 5,3]))
def get_coordinate(matrix, elem):
    for i in matrix:
        for j in i:
            if j == elem:
                return [i, j]
    return None

print(get_coordinate(list(input("put your 2D array here or array")), 1))